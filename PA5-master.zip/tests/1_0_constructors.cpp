#include "graph.h"


Graph<int> g();
Graph<int>* k = new Graph<int>();
delete k;