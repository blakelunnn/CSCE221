#include "Collection.h"
#include "Stress_ball.h"
#include <iostream>
#include <string>
using namespace std;

Collection::Collection()
{
    array = nullptr;
    capacity = 0;
    size = 0;
}
Collection::Collection(const int cap)
{
    capacity = cap;
    size = 0;
    array = new Stress_ball[capacity];
}
Collection::Collection(const Collection &c)
{
    size = c.size;
    capacity = c.capacity;
    array = new Stress_ball[c.capacity];
    for(int x = 0; x < c.size; x++)
        array[x] = c.array[x];
}
void Collection::resize()
{
    int tempCapacity = capacity;
    capacity *= 2;
    if(capacity == 0)
        capacity = 1;

    Stress_ball *tempArray = new Stress_ball[capacity];

    for(int x = 0; x < tempCapacity; x++)
        tempArray[x] = array[x];
    
    delete[] array;
    array = tempArray;
}
Collection& Collection::operator=(const Collection &c)
{
    if(this == &c)
        return *this;
    delete[] array;
    size = c.size;
    capacity = c.capacity;
    array = new Stress_ball[capacity];

    for(int x = 0; x < c.size; x++)
        array[x] = c.array[x];
    
    return *this;
}
Collection::~Collection()
{
    delete[] array;
    array = nullptr;
    size = 0;
    capacity = 0;
}

Collection::Collection(Collection &&c)
{
    array = c.array;

    size = c.size;
    capacity = c.capacity;

    c.size = 0;
    c.capacity = 0;
    c.array = nullptr;
}
Collection &Collection::operator=(Collection &&c)
{
    if(this == &c)
        return *this;
    
    delete[] array;
    size = c.size;
    capacity = c.capacity;
    array = c.array;
    
    c.size = 0;
    c.capacity = 0;
    c.array = nullptr;
    return *this;
}
void Collection::insert_item(const Stress_ball &sb)
{
    if(size == capacity)
        resize();
    
    array[size] = sb;
    size++;
}
bool Collection::contains(const Stress_ball &sb) const
{
    for(int x = 0; x < size; x++)
        if(array[x] == sb)
            return true;
    
    return false;
}
Stress_ball Collection::remove_any_item()
{
    if(size == 0)
        throw "Collection is empty";
    
    int randomItem = rand()%size;
    Stress_ball removeItem = array[randomItem];
    
    for(int x = randomItem; x < size - 1; x++)
        array[randomItem] = array[randomItem + 1];
    
    size--;
    return removeItem;
}
void Collection::remove_this_item(const Stress_ball &sb)
{
    if(size == 0)
        throw "Collection is empty";
    
    bool found = false;
    int index;
    int x = 0;
    while((x < size) && !found)
    {
        if(array[x] == sb)
        {
            found = true;
            index = x;
        }

        x++;
    }

    if(!found)
        throw "This stress ball doesn't exist";
    
    for(int y = index; y < size - 1; y++)
        array[y] = array[y + 1];
    size--;
}
void Collection::make_empty()
{
    delete[] array;
    array = nullptr;
    size = 0;
    capacity = 0;
}
bool Collection::is_empty() const
{
    return size == 0;
}
int Collection::total_items() const
{
    return size;
}
int Collection::total_items(const Stress_ball_sizes s) const
{
    int count = 0;
    for(int x = 0; x < size; x++)
        if(array[x].get_size() == s)
            count++;
    return count;
}
int Collection::total_items(const Stress_ball_colors c) const
{
    int count = 0;
    for(int x = 0; x < size; x++)
        if(array[x].get_color() == c)
            count++;
    return count;
}
void Collection::print_items() const
{
    for(int x = 0; x < size; x++)
        cout << array[x] << endl;
}
Stress_ball &Collection::operator[](int i)
{
    return array[i];
}
const Stress_ball &Collection::operator[](int i) const
{
    return array[i];
}

istream& operator>>(istream &is, Collection &c)
{
    string colr, siz;

    Stress_ball_colors actualColor;
    Stress_ball_sizes actualSize;

    while(!is.eof())
    {
        is >> colr;
        is >> siz;

        if(!(colr.compare("red")))
            actualColor = Stress_ball_colors::red;
        else if(!(colr.compare("blue")))
            actualColor = Stress_ball_colors::blue;
        else if(!(colr.compare("green")))
            actualColor = Stress_ball_colors::green;
        else if(!(colr.compare("yellow")))
            actualColor = Stress_ball_colors::yellow;

        if(!(siz.compare("small")))
            actualSize = Stress_ball_sizes::small;
        else if(!(siz.compare("medium")))
            actualSize = Stress_ball_sizes::medium;
        else if(!(siz.compare("large")))
            actualSize = Stress_ball_sizes::large;

        Stress_ball newSB = Stress_ball(actualColor, actualSize);
        c.insert_item(newSB);
    }

    return is;
}
ostream &operator<<(ostream &os, const Collection &c)
{
    for(int x = 0; x < c.total_items(); x++)
        os << c[x];
    
    return os;
}
Collection make_union(const Collection &c1, const Collection &c2)
{
    Collection unionC = Collection(c1);
    for(int x = 0; x < c2.total_items(); x++)
        unionC.insert_item(c2[x]);
    
    return unionC;
}
void swap(Collection &c1, Collection &c2)
{
    Collection temp = c1;
    c1 = c2;
    c2 = temp;
}
void sort_by_size(Collection &c, const Sort_choice sort)
{
    switch (sort)
    {
        case Sort_choice::bubble_sort:
        {
            for (int x = 0; x < c.total_items() - 1; x++)
                for (int y = 0; y < c.total_items() - x; y++) 
                    if (c[y].get_size() > c[y + 1].get_size()) 
                    {
                        Stress_ball temp1 = c[y];
                        c[y] = c[y + 1];
                        c[y + 1] = temp1;
                    }
            break;
        }
        case Sort_choice::insertion_sort:
        {
            Stress_ball temp2;

            for (int x = 1; x < c.total_items(); x++)
            {
                Stress_ball temp2 = c[x];
                int y = x - 1;
                while ((y >= 0) && (c[y].get_size() > temp2.get_size()))
                {
                    c[y + 1] = temp2;
                    y = y - 1;
                }
                c[y + 1] = temp2;
            }
            break;
        }
        case Sort_choice::selection_sort:
        {
            for (int x = 0; x < c.total_items()-1; x++)
            {
                int index = x;
                for (int y = x + 1; y < c.total_items(); y++)
                    if (c[index].get_size() > c[y].get_size())
                        index = y;
                
                Stress_ball temp3 = c[x];
                c[x] = c[index];
                c[index] = temp3;
            }
            break;
        }
    }
}

//valgrind checks for memory leak, something else for mac
/*insert after(Node* at, Node* n){
    n->prev = at;
    n->next = at->next;

    at->next->prev = n;
    at->next = n
}*/