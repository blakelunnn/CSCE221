#include "Stress_ball.h"
using namespace std;

Stress_ball::Stress_ball()
{
    srand(time(0));
    color = Stress_ball_colors(rand()%4);
    size = Stress_ball_sizes(rand()%3);
}

Stress_ball::Stress_ball(Stress_ball _colors color, Stress_ball_sizes size)
{
    this->color = color;
    this->size = size;
}

Stress_ball_colors Stress_ball::get_color() const
{
    return this->color;
}

Stress_ball_sizes Stress_ball::get_size() const
{
    return this->size;
}

bool Stress_ball::operator==(const Stress_ball &sb) const
{
    return this->size == sb.get_size() && this->color == sb.get_color();
}

ostream& operator<<(ostream& o, const Stress_ball &sb)
{
    string clr;
    switch(sb.get_color())
    {
        case red :
            clr = "red";
            break;
        case blue :
            clr = "blue";
            break;
        case yellow :
            clr = "yellow";
            break;
        case green :
            clr = "green";
            break;
        default :
            clr = "no color";
    }
    string sze;
    switch(sb.get_size())
    {
        case small :
            sze = "small";
            break;
        case medium :
            sze = "medium";
            break;
        case large :
            sze = "large";
            break;
        default :
            sze = "no size";
    }
    o << "(" << clr << ", " << sze << ")";

    return o;
}

//make deliverable UIN=131001178