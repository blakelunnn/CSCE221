#ifndef SORTEDMPQ_H
#define SORTEDMPQ_H

#include <stdexcept>
#include <list>
#include "MPQ.h"

/*
 * Minimum Priority Queue based on a linked list
 */
template <typename T>
class SortedMPQ: MPQ<T> {
   // Implement the four funtions (insert, is_empty, min, remove_min) from MPQ.h
   // To hold the elements use std::list
   // For remove_min() and min() throw exception if the SortedMPQ is empty. Mimir already has a try/catch block so don't use try/catch block here.
   private:
      std::list<T> elements;
   public:
      bool is_empty()
      {
         return elements.empty();
      }
      void insert(const T& data)
      {
         bool added = false;
         if(is_empty())
         {
            elements.push_back(data);
            added = true;
         }
         
         for(auto it = elements.begin(); it != elements.end(); it++)
            if(data < *it)
            {
               elements.insert(it, data);
               added = true;
               break;
            }
         if(!added)
            elements.push_back(data);
      }
      T remove_min()
      {
         if(is_empty())
            throw "caught remove";
         
         T minValue = min();
         elements.pop_front();

         return minValue;
      }
      T min()
      {
         if(is_empty())
            throw "caught min";
         
         return elements.front();
      }
};

#endif