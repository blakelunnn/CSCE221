#ifndef UNSORTEDMPQ_H
#define UNSORTEDMPQ_H

#include <stdexcept>
#include <vector>
#include "MPQ.h"

/**
 * Minimum Priority Queue based on a vector
 */
template <typename T>
class UnsortedMPQ: MPQ<T> {
   // Implement the four funtions (insert, is_empty, min, remove_min) from MPQ.h
   // To hold the elements use std::vector
   // For remove_min() and min() just throw exception if the UnsortedMPQ is empty. Mimir already has a try/catch block so don't use try/catch block here.
   private:
      std::vector<T> elements;
   public:
      bool is_empty()
      {
         if(elements.size() == 0)
            return true;
         return false;
      }
      void insert(const T& data)
      {
         elements.push_back(data);
      }
      T remove_min()
      {
         if(is_empty())
            throw "caught remove";
         
         int minIndex = 0;
         T minValue = elements[0];
         for(size_t x = 0; x < elements.size(); x++)
            if(elements[x] < minValue)
            {
               minIndex = x;
               minValue = elements[x];
            }

         elements[minIndex] = elements.back(); 
         elements.pop_back();
         /* switches the value of the end element with where the min value is 
         so that the value is preserved when it's removed and still unsorted */
         
         return minValue;
      }
      T min()
      {
         if(is_empty())
            throw "caught min";
         T min = elements[0];
         for(auto it = elements.begin(); it != elements.end(); it++)
            if(*it < min)
               min = *it;
         
         return min;
      }
};

#endif