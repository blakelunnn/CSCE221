/**
 * In this file, implement the methods from Jeans.h
 * The implementation is identical to Stress_ball 
 */
#include "Jeans.h"

using namespace std;
Jeans::Jeans()
{
    color = Jeans_colors(rand() % 4);
    size = Jeans_sizes(rand() % 4);
}
Jeans::Jeans(Jeans_colors color, Jeans_sizes size)
{
    this->color = color;
    this->size = size;
}
Jeans_colors Jeans::get_color() const
{
    return this->color;
}
Jeans_sizes Jeans::get_size() const
{
    return this->size;
}
bool Jeans::operator==(const Jeans &j) const
{
    return (this->color == j.color) && (this->size == j.size);
}
istream &operator>>(istream &is, Jeans &j)
{
    string colr, siz;

    Jeans_colors actualColor;
    Jeans_sizes actualSize;

    is >> colr;
    is >> siz;

    if (!(colr.compare("white")))
        actualColor = Jeans_colors::white;
    else if (!(colr.compare("black")))
        actualColor = Jeans_colors::black;
    else if (!(colr.compare("blue")))
        actualColor = Jeans_colors::blue;
    else
        actualColor = Jeans_colors::grey;

    if (!(siz.compare("small")))
        actualSize = Jeans_sizes::small;
    else if (!(siz.compare("medium")))
        actualSize = Jeans_sizes::medium;
    else if (!(siz.compare("large")))
        actualSize = Jeans_sizes::large;
    else
        actualSize = Jeans_sizes::xlarge;

    j.color = actualColor;
    j.size = actualSize;
    return is;
}

ostream &operator<<(std::ostream &os, const Jeans &j)
{
    string clr;
    switch (j.get_color())
    {
    case Jeans_colors::white:
        clr = "white";
        break;
    case Jeans_colors::black:
        clr = "black";
        break;
    case Jeans_colors::blue:
        clr = "blue";
        break;
    case Jeans_colors::grey:
        clr = "grey";
        break;
    default:
        clr = "no color";
    }
    string sze;
    switch (j.get_size())
    {
    case Jeans_sizes::small:
        sze = "small";
        break;
    case Jeans_sizes::medium:
        sze = "medium";
        break;
    case Jeans_sizes::large:
        sze = "large";
        break;
    case Jeans_sizes::xlarge:
        sze = "xlarge";
        break;
    default:
        sze = "no size";
    }
    os << "(" << clr << ", " << sze << ")";

    return os;
}