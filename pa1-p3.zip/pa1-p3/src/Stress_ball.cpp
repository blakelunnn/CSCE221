/**
 * Reuse Stress_ball.cpp from PA1-p2
 * Feel free to make any changes you need
 * None are expected
 */
#include "Stress_ball.h"
using namespace std;

Stress_ball::Stress_ball()
{
    color = Stress_ball_colors(rand() % 4);
    size = Stress_ball_sizes(rand() % 3);
}

Stress_ball::Stress_ball(Stress_ball_colors color, Stress_ball_sizes size)
{
    this->color = color;
    this->size = size;
}

Stress_ball_colors Stress_ball::get_color() const
{
    return this->color;
}

Stress_ball_sizes Stress_ball::get_size() const
{
    return this->size;
}

bool Stress_ball::operator==(const Stress_ball &sb) const
{
    return this->size == sb.get_size() && this->color == sb.get_color();
}

istream &operator>>(istream &is, Stress_ball &sb)
{
    string colr, siz;

    Stress_ball_colors actualColor;
    Stress_ball_sizes actualSize;

    is >> colr;
    is >> siz;

    if (!(colr.compare("red")))
        actualColor = Stress_ball_colors::red;
    else if (!(colr.compare("blue")))
        actualColor = Stress_ball_colors::blue;
    else if (!(colr.compare("green")))
        actualColor = Stress_ball_colors::green;
    else
        actualColor = Stress_ball_colors::yellow;

    if (!(siz.compare("small")))
        actualSize = Stress_ball_sizes::small;
    else if (!(siz.compare("medium")))
        actualSize = Stress_ball_sizes::medium;
    else
        actualSize = Stress_ball_sizes::large;

    sb.color = actualColor;
    sb.size = actualSize;
    return is;
}
ostream &operator<<(ostream &o, const Stress_ball &sb)
{
    string clr;
    switch (sb.get_color())
    {
    case Stress_ball_colors::red:
        clr = "red";
        break;
    case Stress_ball_colors::blue:
        clr = "blue";
        break;
    case Stress_ball_colors::yellow:
        clr = "yellow";
        break;
    case Stress_ball_colors::green:
        clr = "green";
        break;
    default:
        clr = "no color";
    }
    string sze;
    switch (sb.get_size())
    {
    case Stress_ball_sizes::small:
        sze = "small";
        break;
    case Stress_ball_sizes::medium:
        sze = "medium";
        break;
    case Stress_ball_sizes::large:
        sze = "large";
        break;
    default:
        sze = "no size";
    }
    o << "(" << clr << ", " << sze << ")";

    return o;
}

//make deliverable UIN=131001178