/**
 * There is no Collection.cpp for this assignment.
 * Move all the functions from Collection.cpp to this file
 * Covert the Collection class to a templated form.
 *      Stress_ball should be replaced with typename "Obj".
 *      Stress_ball_colors
 *      Stress_ball_sizes should be replaced with typename "F2"
 */

#ifndef COLLECTION_H
#define COLLECTION_H
#include <exception>
#include <string>
#include <iostream>

using namespace std;
enum class Sort_choice
{
    bubble_sort,
    insertion_sort,
    selection_sort
};

struct EmptyCollectionException : public std::exception
{
	const char * what () const noexcept
    {
        return "Collection is Empty!";
    }
};

template <typename Obj, typename F1, typename F2>
class Collection
{
    Obj *array;
    int size;
    int capacity;
    void resize()
    {
        int tempCapacity = capacity;
        capacity *= 2;
        if(capacity == 0)
           capacity = 1;

        Obj *tempArray = new Obj[capacity];

        for(int x = 0; x < tempCapacity; x++)
            tempArray[x] = array[x];
    
        delete[] array;
        array = tempArray;
    };

public:
    Collection()
    {
        array = nullptr;
        capacity = 0;
        size = 0;
    };
    Collection(const int cap)
    {
        capacity = cap;
        size = 0;
        array = new Obj[capacity];
    };
    Collection(const Collection &c)
    {
        size = c.size;
        capacity = c.capacity;
        array = new Obj[c.capacity];
        for(int x = 0; x < c.size; x++)
            array[x] = c.array[x];
    };
    Collection &operator=(const Collection &c)
    {
        if(this == &c)
            return *this;
        delete[] array;
        size = c.size;
        capacity = c.capacity;
        array = new Obj[capacity];

        for(int x = 0; x < c.size; x++)
            array[x] = c.array[x];
    
        return *this;
    };
    ~Collection()
    {
        delete[] array;
        array = nullptr;
        size = 0;
        capacity = 0;
    };
    Collection(Collection &&c)
    {
        array = c.array;

        size = c.size;
        capacity = c.capacity;

        c.size = 0;
        c.capacity = 0;
        c.array = nullptr;
    };
    Collection &operator=(Collection &&c)
    {
        if(this == &c)
            return *this;
    
        delete[] array;
        size = c.size;
        capacity = c.capacity;
        array = c.array;
    
        c.size = 0;
        c.capacity = 0;
        c.array = nullptr;
        return *this;
    };
    void insert_item(const Obj &sb)
    {
        if(size == capacity)
            resize();
    
        array[size] = sb;
        size++;
    };
    bool contains(const Obj &sb) const
    {
        for(int x = 0; x < size; x++)
            if(array[x] == sb)
                return true;
    
        return false;
    };
    Obj remove_any_item()
    {
        if(size == 0)
            throw "Collection is empty";
    
        int randomItem = rand()%size;
        Obj removeItem = array[randomItem];
    
        for(int x = randomItem; x < size - 1; x++)
            array[randomItem] = array[randomItem + 1];
    
        size--;
        return removeItem;
    };
    void remove_this_item(const Obj &sb)
    {
        if(size == 0)
            throw "Collection is empty";
    
        bool found = false;
        int index;
        int x = 0;
        while((x < size) && !found)
        {
            if(array[x] == sb)
            {
                found = true;
                index = x;
            }

            x++;
        }

        if(!found)
            throw "This stress ball doesn't exist";
    
        for(int y = index; y < size - 1; y++)
            array[y] = array[y + 1];
        size--;
    };
    void make_empty()
    {
        delete[] array;
        array = nullptr;
        size = 0;
        capacity = 0;
    };
    bool is_empty() const
    {
        return size == 0;
    };
    int total_items() const
    {
        return size;
    };
    int total_items(const F2 s) const
    {
        int count = 0;
        for(int x = 0; x < size; x++)
            if(array[x].get_size() == s)
                count++;
        return count;
    };
    int total_items(const F1 c) const
    {
        int count = 0;
        for(int x = 0; x < size; x++)
            if(array[x].get_color() == c)
                count++;
        return count;
    };
    void print_items() const
    {
        for(int x = 0; x < size; x++)
            cout << array[x] << endl;
    };
    Obj &operator[](const int i)
    {
        return array[i];
    };
    const Obj &operator[](const int i) const
    {
        return array[i];
    };
};

template <typename Obj, typename F1, typename F2>
istream& operator>>(istream &is, Collection<Obj, F1, F2> &c)
{
    Obj temp;
    while(is >> temp)
    {
        c.insert_item(temp);
    }

    return is;
}
template <typename Obj, typename F1, typename F2>
ostream &operator<<(ostream &os, const Collection<Obj, F1, F2> &c)
{
    for(int x = 0; x < c.total_items(); x++)
        os << c[x] << endl;
    
    return os;
}
template <typename Obj, typename F1, typename F2>
Collection<Obj, F1, F2> make_union(const Collection<Obj, F1, F2> &c1, const Collection<Obj, F1, F2> &c2)
{
    Collection<Obj, F1, F2> unionC = Collection(c1);
    for(int x = 0; x < c2.total_items(); x++)
        unionC.insert_item(c2[x]);
    
    return unionC;
}

template <typename Obj, typename F1, typename F2>
void swap(Collection<Obj, F1, F2> &c1, Collection<Obj, F1, F2> &c2)
{
    Collection<Obj, F1, F2> temp = c1;
    c1 = c2;
    c2 = temp;
}

template <typename Obj, typename F1, typename F2>
void sort_by_size(Collection<Obj, F1, F2> &c, const Sort_choice sort)
{
    switch (sort)
    {
        case Sort_choice::bubble_sort:
        {
            for (int x = 0; x < c.total_items() - 1; x++)
                for (int y = 0; y < c.total_items() - x; y++) 
                    if (c[y].get_size() > c[y + 1].get_size()) 
                    {
                        Obj temp1 = c[y];
                        c[y] = c[y + 1];
                        c[y + 1] = temp1;
                    }
            break;
        }
        case Sort_choice::insertion_sort:
        {
            Obj temp2;

            for (int x = 1; x < c.total_items(); x++)
            {
                Obj temp2 = c[x];
                int y = x - 1;
                while ((y >= 0) && (c[y].get_size() > temp2.get_size()))
                {
                    c[y + 1] = temp2;
                    y = y - 1;
                }
                c[y + 1] = temp2;
            }
            break;
        }
        case Sort_choice::selection_sort:
        {
            for (int x = 0; x < c.total_items()-1; x++)
            {
                int index = x;
                for (int y = x + 1; y < c.total_items(); y++)
                    if (c[index].get_size() > c[y].get_size())
                        index = y;
                
                Obj temp3 = c[x];
                c[x] = c[index];
                c[index] = temp3;
            }
            break;
        }
    }
}

#endif
