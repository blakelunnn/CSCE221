BSTree t{};
ASSERT_EQ(t.get_root(),nullptr);
ASSERT_EQ(t.get_size(),0);