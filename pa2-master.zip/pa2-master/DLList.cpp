// implementation of the DLList class

#include "DLList.h"

using namespace std;

DLList::DLList()
{
    header.next = &trailer;
    trailer.prev = &header;
}
DLList::DLList(const DLList &dll) // copy constructor
{
    const DLListNode *temp = dll.header.next;
    this->header.next = &this->trailer;
    this->trailer.prev = &this->header;
    while ((temp = temp->next))
      this->insert_last(temp->prev->obj);
}
DLList::DLList(DLList &&dll) // move constructor
{
    if (is_empty())
    {
      header.next = &trailer;
      trailer.prev = &header;
      return;
    }
    header.next->prev = &header;
    trailer.prev->next = &trailer;
    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;
}
DLList::~DLList() // destructor
{
    DLListNode *prev_node, *node = header.next;
    while (node != &trailer)
    {
        prev_node = node;
        node = node->next;
        delete prev_node;
    }
    header.next = &trailer;
    trailer.prev = &header;
}
DLList &DLList::operator=(const DLList &dll) // copy assignment operator
{
    if (this != &dll)
    {
      make_empty();
      const DLListNode *temp = dll.header.next;
      this->header.next = &this->trailer;
      this->trailer.prev = &this->header;
      while ((temp = temp->next))
        this->insert_last(temp->prev->obj);
    }
    return *this;
}
DLList &DLList::operator=(DLList &&dll) // move assignment operator
{
    if (this != &dll)
    {
      if (is_empty())
      {
        header.next = &trailer;
        trailer.prev = &header;
        return *this;
      }
      header.next = dll.header.next;
      trailer.prev = dll.trailer.prev;
      header.next->prev = &header;
      trailer.prev->next = &trailer;
      dll.header.next = &dll.trailer;
      dll.trailer.prev = &dll.header;
    }
    return *this;
}

// return the pointer to the first node (header's next)
DLList::DLListNode *DLList::first_node() const
{
    return header.next;
}

// return the pointer to the trailer
const DLList::DLListNode *DLList::after_last_node() const
{
    return &trailer;
}

// return if the list is empty
bool DLList::is_empty() const
{
    return header.next == &trailer;
}

int DLList::first() const // return the first object
{
    if (is_empty())
        throw "DLList is empty";
    return header.next->obj;
}
int DLList::last() const // return the last object
{
    if (is_empty())
        throw "DLList is empty";
    return trailer.prev->obj;
}
void DLList::insert_first(const int obj) // insert to the first node
{
    insert_after(header, obj);
}
int DLList::remove_first() // remove the first node
{
    if (is_empty())
        throw "DLList is empty";
    int value = header.next->obj;

    DLListNode *temp = header.next;
    temp->next->prev = &header;
    header.next = temp->next;
    temp->next->prev = &header;
    delete temp;
    return value;
}
void DLList::insert_last(const int obj) // insert to the last node
{
    insert_after(*trailer.prev, obj);
}
int DLList::remove_last() // remove the last node
{
    if (is_empty())
        throw "DLList is empty";

    int value = trailer.prev->obj;
    DLListNode *temp = trailer.prev;
    temp->prev->next = &trailer;
    trailer.prev = temp->prev;
    delete temp;

    return value;
}
void DLList::insert_after(DLListNode &p, const int obj)
{
    if (p.next == nullptr)
        throw "invalid entry";

    DLListNode *newNode = new DLListNode(obj, &p, p.next);
    p.next->prev = newNode;
    p.next = newNode;
}
void DLList::insert_before(DLListNode &p, const int obj)
{
    DLListNode *newNode = new DLListNode(obj, p.prev, &p);
    p.prev->next = newNode;
    p.prev = newNode;
}
int DLList::remove_after(DLListNode &p)
{
    if (is_empty())
        throw "DLList is empty";

    if (p.next == &trailer)
        throw "invalid entry";

    DLListNode *temp = p.next;
    int value = p.next->obj;
    temp->prev->next = temp->next;
    temp->next->prev = temp->prev;

    delete temp;

    return value;
}
int DLList::remove_before(DLListNode &p)
{
    if (is_empty())
        throw "DLList is empty";

    if (p.prev == &header)
        throw "invalid entry";

    DLListNode *temp = p.prev;
    int value = p.prev->obj;
    temp->prev->next = temp->next;
    temp->next->prev = temp->prev;

    delete temp;

    return value;
}
void DLList::make_empty(void)
{

    DLListNode *prev_node, *node = header.next;
    while (node != &trailer)
    {
        prev_node = node;
        node = node->next;
        delete prev_node;
    }
    header.next = &trailer;
    trailer.prev = &header;
    /*const DLListNode *temp = header.next;

    while ((temp = temp->next) != nullptr)
        delete temp->prev;*/
}

ostream &operator<<(ostream &out, const DLList &dll)
{
    const DLList::DLListNode *temp = dll.first_node();
    while (temp != dll.after_last_node())
    {
        out << temp->obj << ", ";
        temp = temp->next;
    }
    return out;
}