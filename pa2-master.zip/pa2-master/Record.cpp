//implementation of record class

#include "Record.h"

Record::Record()
{
    title = "";
    author = "";
    ISBN = "";
    year = "";
    edition = "";
}
Record::Record(string title, string author, string ISBN, string year, string edition)
{
    this->title = title;
    this->author = author;
    this->ISBN = ISBN;
    this->year = year;
    this->edition = edition;
}
string Record::get_title(void) const
{
    return title;
}
string Record::get_author(void) const
{
    return author;
}
string Record::get_ISBN(void) const
{
    return ISBN;
}
string Record::get_year(void) const
{
    return year;
}
string Record::get_edition(void) const
{
    return edition;
}

void Record::set_title(string s)
{
    title = s;
}
void Record::set_author(string s)
{
    author = s;
}
void Record::set_ISBN(string s)
{
    ISBN = s;
}
void Record::set_year(string s)
{
    year = s;
}
void Record::set_edition(string s)
{
    edition = s;
}

std::istream& operator>>(std::istream& is, Record& rec)
{
    string HOLD, TITLE, AUTHOR, ISBN, YEAR, EDITION;
    getline(is, TITLE, '\n');
    if(TITLE == "")
        getline(is, TITLE, '\n');
    getline(is, AUTHOR, '\n');
    getline(is, ISBN, '\n');
    getline(is, YEAR, '\n');
    getline(is, EDITION, '\n');

    rec.set_title(TITLE);
    rec.set_author(AUTHOR);
    rec.set_ISBN(ISBN);
    rec.set_year(YEAR);
    rec.set_edition(EDITION);

    return is;
}
std::ostream& operator<<(std::ostream& os, Record& rec)
{
    os << rec.get_title() << endl;
    os << rec.get_author() << endl;
    os << rec.get_ISBN() << endl;
    os << rec.get_year() << endl;
    os << rec.get_edition() << endl;

    return os;
}

bool operator==(const Record& r1, const Record& r2)
{
    return (r1.get_title() == r2.get_title() && r1.get_author() == r2.get_author() && r1.get_ISBN() == r2.get_ISBN());
}
bool operator<(const Record& lhs, const Record& rhs)
{
    if(lhs.get_title() < rhs.get_title())
        return lhs.get_title() < rhs.get_title();
    
    if(lhs.get_author() < rhs.get_author())
        return lhs.get_author() < rhs.get_author();
    
    return lhs.get_ISBN() < rhs.get_ISBN();
}