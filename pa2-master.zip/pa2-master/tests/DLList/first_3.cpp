// First element inserted with insert_last
DLList dll3;
dll3.insert_last(1);

ASSERT_EQ(dll3.first(), 1);