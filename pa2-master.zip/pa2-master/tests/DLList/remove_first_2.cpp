DLList dll2;
ASSERT_ANY_THROW(dll2.remove_first());