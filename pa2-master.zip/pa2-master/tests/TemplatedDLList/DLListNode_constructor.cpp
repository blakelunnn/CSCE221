
#include <string>
TemplatedDLList<std::string>::DLListNode stringDLLN;
ASSERT_TRUE(stringDLLN.obj == "");