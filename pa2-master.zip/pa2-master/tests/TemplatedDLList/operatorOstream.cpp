
// this is handled by Mimir directly
ASSERT(true);