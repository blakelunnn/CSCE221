TemplatedDLList<int> dll2;
ASSERT_ANY_THROW(dll2.remove_before(*dll2.first_node()));