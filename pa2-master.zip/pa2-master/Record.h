#ifndef Record_H
#define Record_H

#include <iostream>
#include <string>

using namespace std;

class Record {
private:
    //member variables
    string title;
    string author;
    string ISBN;
    string year;
    string edition;
public:
    //accessor/mutator functions
    // std::string get_title(void) const;
    // ... for all 5 fields
    Record();
    Record(string title, string author, string ISBN, string year, string edition);
    string get_title(void) const;
    string get_author(void) const;
    string get_ISBN(void) const;
    string get_year(void) const;
    string get_edition(void) const;

    void set_title(string s);
    void set_author(string s);
    void set_ISBN(string s);
    void set_year(string s);
    void set_edition(string s);
};

// Stream operators
std::istream& operator>>(std::istream& is, Record& rec);
std::ostream& operator<<(std::ostream& os, Record& rec);

// Comparison operators
bool operator==(const Record& r1, const Record& r2);
bool operator<(const Record& lhs, const Record& rhs);
#endif