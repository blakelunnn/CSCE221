// header file for the templated DLList

#ifndef TEMPLATEDDLLIST_H
#define TEMPLATEDDLLIST_H

#include <iostream>

using namespace std;

// doubly linked list class
template <typename T>
class TemplatedDLList
{
public:
  struct DLListNode
  {
    T obj;
    DLListNode *prev, *next;
    // constructor
    DLListNode(T e = T(), DLListNode *p = nullptr, DLListNode *n = nullptr) : obj(e), prev(p), next(n) {}
  };
  // doubly linked list node
private:
  DLListNode header, trailer;

public:
  TemplatedDLList(void) : header(), trailer() // default constructor
  {
    header.next = &trailer;
    trailer.prev = &header;
  }
  TemplatedDLList(const TemplatedDLList<T> &dll) : header(), trailer() // copy constructor
  {
    const DLListNode *temp = dll.header.next;
    this->header.next = &this->trailer;
    this->trailer.prev = &this->header;
    while ((temp = temp->next))
      this->insert_last(temp->prev->obj);
  }
  TemplatedDLList(TemplatedDLList<T> &&dll) // move constructor
  {
    if (is_empty())
    {
      header.next = &trailer;
      trailer.prev = &header;
      return;
    }
    header.next->prev = &header;
    trailer.prev->next = &trailer;
    dll.header.next = &dll.trailer;
    dll.trailer.prev = &dll.header;
  }
  ~TemplatedDLList() // destructor
  {
    DLListNode *prev_node, *node = header.next;
    while (node != &trailer)
    {
      prev_node = node;
      node = node->next;
      delete prev_node;
    }
    header.next = &trailer;
    trailer.prev = &header;
  }
  TemplatedDLList<T> &operator=(const TemplatedDLList<T> &dll) // copy assignment operator
  {
    if (this != &dll)
    {
      make_empty();
      const DLListNode *temp = dll.header.next;
      this->header.next = &this->trailer;
      this->trailer.prev = &this->header;
      while ((temp = temp->next))
        this->insert_last(temp->prev->obj);
    }
    return *this;
  }
  TemplatedDLList<T> &operator=(TemplatedDLList<T> &&dll) // move assignment operator
  {
    if (this != &dll)
    {
      if (is_empty())
      {
        header.next = &trailer;
        trailer.prev = &header;
        return *this;
      }
      header.next = dll.header.next;
      trailer.prev = dll.trailer.prev;
      header.next->prev = &header;
      trailer.prev->next = &trailer;
      dll.header.next = &dll.trailer;
      dll.trailer.prev = &dll.header;
    }
    return *this;
  }

  // return the pointer to the first node
  DLListNode *first_node(void) const
  {
    return header.next;
  }

  // return the pointer to the trailer
  const DLListNode *after_last_node(void) const
  {
    return &trailer;
  }

  // return true if the list is empty
  bool is_empty(void) const
  {
    return header.next == &trailer;
  }

  T first(void) const // return the first object
  {
    return header.next->obj;
  }
  T last(void) const // return the last object
  {
    return trailer.prev->obj;
  }
  void insert_first(const T obj) // insert to the first node
  {
    DLListNode *newNode = new DLListNode(obj, &header, header.next);
    header.next->prev = newNode;
    header.next = newNode;
  }
  T remove_first() // remove the first node
  {
    if (is_empty())
      throw "DLList is empty";
    int value = header.next->obj;

    DLListNode *temp = header.next;
    temp->next->prev = &header;
    header.next = temp->next;
    temp->next->prev = &header;
    delete temp;
    return value;
  }
  void insert_last(const T obj) // insert to the last node
  {
    DLListNode *newNode = new DLListNode(obj, trailer.prev, &trailer);
    trailer.prev->next = newNode;
    trailer.prev = newNode;
  }
  T remove_last()
  {
    if (is_empty())
      throw "DLList is empty";

    int value = trailer.prev->obj;
    DLListNode *temp = trailer.prev;
    temp->prev->next = &trailer;
    trailer.prev = temp->prev;
    delete temp;

    return value;
  }
  void insert_after(DLListNode &p, const T obj)
  {
    if (p.next == nullptr)
      throw "invalid entry";

    DLListNode *newNode = new DLListNode(obj, &p, p.next);
    p.next->prev = newNode;
    p.next = newNode;
  }
  void insert_before(DLListNode &p, const T obj)
  {
    DLListNode *newNode = new DLListNode(obj, p.prev, &p);
    p.prev->next = newNode;
    p.prev = newNode;
  }
  T remove_after(DLListNode &p)
  {
    if (is_empty())
      throw "DLList is empty";

    if (p.next == &trailer)
      throw "invalid entry";

    DLListNode *temp = p.next;
    int value = p.next->obj;
    temp->prev->next = temp->next;
    temp->next->prev = temp->prev;

    delete temp;

    return value;
  }
  T remove_before(DLListNode &p)
  {
    if (is_empty())
      throw "DLList is empty";

    if (p.prev == &header)
      throw "invalid entry";

    DLListNode *temp = p.prev;
    int value = p.prev->obj;
    temp->prev->next = temp->next;
    temp->next->prev = temp->prev;

    delete temp;

    return value;
  }
  void make_empty(void)
  {
    DLListNode *prev_node, *node = header.next;
    while (node != &trailer)
    {
      prev_node = node;
      node = node->next;
      delete prev_node;
    }
    header.next = &trailer;
    trailer.prev = &header;
  }
};

// output operator
template <typename T>
std::ostream &operator<<(std::ostream &os, const TemplatedDLList<T> &dll)
{
  const typename TemplatedDLList<T>::DLListNode *temp = dll.first_node();
  while ((temp = temp->next))
    os << temp->prev->obj << ", ";
  return os;
}

#endif
