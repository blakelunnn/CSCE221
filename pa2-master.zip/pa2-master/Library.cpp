#include "Library.h"

using namespace std;

std::vector<Record> Library::search(const std::string title) const
{
    int index = title[0] - 'A';
    vector<Record> matchedRecords;
    TemplatedDLList<Record>::DLListNode *tempNode = book_db.at(index).first_node();
    while (tempNode != book_db.at(index).after_last_node())
    {
        if (title == tempNode->obj.get_title())
            matchedRecords.push_back(tempNode->obj);

        tempNode = tempNode->next;
    }

    return matchedRecords;
}

//Imports records from a file.  Does not import duplicates.
// Return the number of records added to the database
int Library::import_database(const std::string filename)
{
    ifstream ifs(filename);
    int index = 0;
    int numRecords = 0;
    Record temp;

    while (ifs >> temp)
    {
        index = (temp.get_title())[0] - 'A';
        bool duplicate = false;
        TemplatedDLList<Record>::DLListNode *tempNode = book_db.at(index).first_node();
        while (tempNode != book_db.at(index).after_last_node())
        {
            if (temp == tempNode->obj)
                duplicate = true;

            tempNode = tempNode->next;
        }
        if (!duplicate && index >= 0 && index <= 25)
        {
            book_db.at(index).insert_last(temp);
            numRecords++;
        }
    }

    ifs.close();
    return numRecords;
}

//Exports the current database to a file
//Return the number of records exported
int Library::export_database(const std::string filename) const
{
    int numRecords = 0;
	ofstream ofs (filename);
	for (size_t x = 0; x < book_db.size(); x++)
    {
		TemplatedDLList<Record>::DLListNode* temp = book_db.at(x).first_node();
		while (temp != book_db.at(x).after_last_node())
        {
			ofs << temp->obj;
			numRecords++;
			temp = temp->next;
		}
	}

	ofs.close();
	return numRecords;
}

void Library::print_database() const
{
    TemplatedDLList<Record>::DLListNode *tempNode;
    for (size_t x = 0; x < book_db.size(); x++)
    {
        tempNode = book_db.at(x).first_node();
        while (tempNode != book_db.at(x).after_last_node())
        {
            cout << tempNode->obj << endl;
            tempNode = tempNode->next;
        }
    }
}

//add record to database, avoid complete duplicates
//  return true if unique
bool Library::add_record(const Record r)
{
    int index = (r.get_title())[0] - 'A';
    bool duplicate = false;
    TemplatedDLList<Record>::DLListNode *tempNode = book_db.at(index).first_node();
    while (tempNode != book_db.at(index).after_last_node())
    {
        if (r == tempNode->obj)
            duplicate = true;

        tempNode = tempNode->next;
    }
    if (!duplicate && index >= 0 && index <= 25)
        book_db.at(index).insert_last(r);
    return !duplicate;
}

//Deletes a record from the database
void Library::remove_record(const Record r)
{
    int index = (r.get_title())[0] - 'A';
    TemplatedDLList<Record>::DLListNode *tempNode = book_db.at(index).first_node();
    while (tempNode != book_db.at(index).after_last_node())
    {
        if (r == tempNode->obj)
        {
            tempNode->prev->next = tempNode->next;
            tempNode->next->prev = tempNode->prev;

            delete tempNode;

            break;
        }
        tempNode = tempNode->next;
    }
}